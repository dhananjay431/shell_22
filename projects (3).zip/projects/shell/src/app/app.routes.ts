import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  {
    path: '',
    loadComponent: () => import('./home.component').then((m) => m.HomeComponent),
    children: [
      {
        path: 'payx',
        children: [
          {
            path: '',
            loadComponent: () =>
              loadRemoteModule('mfe1', './Component').then((module) => module.App),
          },
          {
            path: 'dashboard',
            loadComponent: () =>
              loadRemoteModule('mfe1', './Dashboard').then((module) => module.DashboardComponent),
          },
        ],
      },
    ],
  },

  {
    path: 'login',
    loadComponent: () => import('./login.component').then((m) => m.LoginComponent),
  },
  { path: '**', redirectTo: 'home' },
];
