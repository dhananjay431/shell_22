import { Injectable, signal } from '@angular/core';

/**
 * Shared application state that can be consumed by the shell and remotes.
 *
 * The service deliberately has no dependency on either application so it can
 * be reused by independently built Native Federation projects.
 */
@Injectable({ providedIn: 'root' })
export class CommonService {
  private readonly message = signal('');

  readonly message$ = this.message.asReadonly();

  setMessage(message: string): void {
    this.message.set(message);
  }

  clearMessage(): void {
    this.message.set('');
  }
}
