import { Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonService } from '../../../shared/common.service';

@Component({
  imports: [RouterOutlet],
  selector: 'app-root',
  styleUrl: './app.scss',
  templateUrl: './app.html',
})
export class App {
  private readonly commonService = inject(CommonService);
  protected readonly title = signal('shell');

  constructor() {
    this.commonService.setMessage('Shell is ready');
  }
}
